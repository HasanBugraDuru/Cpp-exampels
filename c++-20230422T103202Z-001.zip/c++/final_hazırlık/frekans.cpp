#include<iostream>

using namespace std;

int main(){
	cout<<"Siz -1 girene kadar sayi alimi devam edicek";
	int sayi=0;
	int sayilar[1000];
	int miktar[10];
	for(int i=0;i<10;i++){
		 miktar[i]=0;
	}
	cout<<"lutfen say� giriniz";
	cin>>sayilar[sayi];
	while(sayilar[sayi]!=-1){
	sayi++;	
	cout<<"lutfen say� giriniz";
	cin>>sayilar[sayi];
	}
	
	for(sayi;sayi>=0;sayi--){
		
		switch(sayilar[sayi]){
			case 1:
				miktar[1]++;
				break;
			case 2:
				miktar[2]++;
				break;
			case 3:
				miktar[3]++;
				break;
			case 4:
				miktar[4]++;
				break;
			case 5:
				miktar[5]++;
				break;
			case 6:
				miktar[6]++;
				break;
			case 7:
				miktar[7]++;
				break;
			case 8:
				miktar[8]++;
				break;
			case 9:
				miktar[9]++;
				break;
			case 0:
				miktar[0]++;
				break;
				
		
		}
		
	}
	
	cout<<"girdi�inz sayilarin mikrati";
	for(int i=0;i<10;i++){
		cout<<i<<"="<<	miktar[i]<<endl;
	}
}
