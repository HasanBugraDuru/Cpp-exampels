#include<iostream>
using namespace std;
	

int main(){
	int num;	
	cout<<"please enter number:";
	cin>>num;
	
	for(num;num>0;num--){
		cout<<endl;
		for(int i=num;i>0;i--){
			cout<<"* ";
		}
		
	}
	
	
	
}
