#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	ofstream outfile;
	outfile.open("dosyaadi.txt");
	
	int num,flag=0;
	
	cout<<"please enter number";
	cin>>num;
	
	for(int i=2;i<num;i++){
		flag=0;
		for(int t=2;t<=i;t++)
		{
			if(i%t==0 & t!=i){
				flag=1;
			}
		}
		if(flag==0){
				outfile<<i;
		}
	
		
	}
	outfile.close();
}
