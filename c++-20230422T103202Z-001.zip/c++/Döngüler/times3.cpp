#include<iostream>
using namespace std;
int main()
{
	int num,one,ten,hun;
	
	for(num=100;num<999;num++)
	{
	one= num%10;
	hun=num/100;
	ten=num%100;
	ten= ten/10;
	one=one*one*one;
	ten=ten*ten*ten;
	hun=hun*hun*hun;
	if(num==ten+one+hun)
	cout<<"its an armstrong number ="<<num<<endl;
	}
}
