#include<iostream>
using namespace std;

int main()
{
	int sum=0;
	for(int i=0;i<1000;i++)
	{
		if(i%5==0 and i%7==0)
		sum+=i;
	}
	
	cout<<"sum is= "<<sum;
	
}
