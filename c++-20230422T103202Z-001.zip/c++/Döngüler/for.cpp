#include<iostream>
using namespace std;
int main ()
{
	int kup;
	for(int i=0;i<12;i++)
	{
	
		kup=(i+3)*(i+3)*(i+3);
		cout<<kup<<endl;
		
	}
	
}
