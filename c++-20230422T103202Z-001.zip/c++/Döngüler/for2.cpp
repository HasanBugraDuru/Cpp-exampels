#include<iostream>
using namespace std;

int main ()
{
	int n,sum;
	
	cout<<"please enter the numer =";
	cin>>n;
	
	for(int i=1;i<=n;i++)
	{
		sum+=i;
	}	
	
	cout<<"Sum is ="<<sum;
	
}

