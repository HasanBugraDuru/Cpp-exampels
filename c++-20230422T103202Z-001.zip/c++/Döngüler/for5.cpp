#include<iostream>
using namespace std;

int main()
{
	int num1,num2;
	
	cout<<"please enter the first number";
	cin>>num1;
	cout<<"please enter the second number";
	cin>>num2;
	num1++;
    for(num1;num1<num2;num1++)
    {
    	cout<<num1<<endl;
	}
	
	
}
