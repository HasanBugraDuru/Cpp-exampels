#include<iostream>
using namespace std;

int main()
{
	int num,result=1;
	
	cout<<"please enter your number";
	cin>>num;
	
	
	for(int i=1;i<=num;i++)
	{
		result *= i;
		
	}
	cout<<"Factorial of number is = "<<result;
}
