#include<iostream>
using namespace std;


int main()
{
int flag;
	for(int i=2;i<500;i++)
	{
		 flag=1;
		for(int f=2s;f<i;f++)
		{
			if(i%f==0)
			{
				flag=0;
			}
			
			
		}
		
		if(flag==1)
		{
			cout<<i<<endl;
		}
		
	}
	
}
