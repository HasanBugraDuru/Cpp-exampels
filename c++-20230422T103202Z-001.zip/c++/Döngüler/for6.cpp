#include<iostream>
using namespace std;

int main()
{
	for(int i=40;i>4;i--)
	{
		if(i%2==0)
		cout<<i<<" is a double number"<<endl;
		
	}
	
}
