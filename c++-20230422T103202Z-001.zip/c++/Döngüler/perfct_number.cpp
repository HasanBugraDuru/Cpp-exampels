#include<iostream>
using namespace std;

int main()
{
	int num1,num2,sum=0;
	
	cout<<"please enter the first number =";
	cin>>num1;
	cout<<"please enter the second number =";
	cin>>num2;
		
	if(num1>num2)
	{
		for(int j=num2+1;j<num1;j++)
		{
			sum=0;
			for(int i=1;i<j;i++)
			{
				if(j%i==0)
				sum+=i;
				
			}
			if(sum==j)
			cout<<j<<" is a perfect number"<<endl;
			
		}
	}
	else
	cout<<"The first number must be greater than the second number!";
	
}
