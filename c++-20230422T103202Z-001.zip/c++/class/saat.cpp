#include<iostream>
using namespace std;

class Zaman{
	int saat;
	int dakika;
	int Saniye;
	public:
	Zaman(){
		cout<<"Please Enter saat";
		cin>>saat;
		
		cout<<"Please Enter dakika";
		cin>>dakika;
		
		cout<<"Please Enter saniye";
		cin>>Saniye;
		
		cout<<saat<<"."<<dakika<<"."<<Saniye;
	}
	
};

int main()
{
	Zaman zaman1();
}
