#include<iostream>
using namespace std;
int main()
{
	int num;
	int *ptr;
	cout<<"Please enter the number";
	cin>>num;
	ptr=&num;
	cout<<ptr;
	
}
