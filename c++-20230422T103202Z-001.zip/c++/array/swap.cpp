#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	char word[20];
	char swap[20];
	cout<<"Please Enter The word";
	cin>>word;
	cout<<strlen(word);
	for(int i=0;i<strlen(word);i++)
	{
	swap[i]=word[strlen(word)-i-1];
	}

	cout<<swap;
	return 0;
}



