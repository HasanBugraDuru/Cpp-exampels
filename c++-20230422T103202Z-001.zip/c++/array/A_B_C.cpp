#include<iostream>
using namespace std;

int main()
{
	int A[2][2];
	int B[2][2];
	int C[2][2];
	
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<"please enter the "<<i<<","<<j<<" number for A =";
			cin>>A[i][j];
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<"please enter the "<<i<<","<<j<<" number for B =";
			cin>>B[i][j];
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			C[i][j]=A[i][j]*B[i][j];
			cout<<C[i][j]<<" ";
		}
		cout<<endl;
	}
	
	
}
