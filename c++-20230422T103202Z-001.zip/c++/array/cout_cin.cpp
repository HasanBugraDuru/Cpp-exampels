#include<iostream>
using namespace std;

int main()
{
	int nums[10];
	
	for(int i=0;i<10;i++)
	{
		cout<<"please enter "<<i+1<<".number =";
		cin>>nums[i];
	}
	for(int i=0;i<10;i++)
	{
		cout<<nums[i]<<endl;
	}
	
}
