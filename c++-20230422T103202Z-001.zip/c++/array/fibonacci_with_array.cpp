#include<iostream>
using namespace std;

int main()
{
	int fibonacci[15];
	fibonacci[0]=0;
	fibonacci[1]=1;
	
	cout<<fibonacci[0]<<" ";
	cout<<fibonacci[1]<<" ";
	for(int i=2;i<15;i++)
	{
		fibonacci[i]=fibonacci[i-1]+fibonacci[i-2];
		cout<<fibonacci[i]<<" ";
	}
	
}
