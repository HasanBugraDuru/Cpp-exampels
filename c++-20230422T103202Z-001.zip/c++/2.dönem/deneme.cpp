#include <iostream>
#include<cmath>
using namespace std;

class Point{
 double x;
 double y;
 
 public:
    double getX()
    {
        return(x);
    }
    
    double gety()
    {
        return(y);
    }
 
 
 Point(double nx,double ny)
 {
     x=nx;
     y=ny;
     cout<<"this is constructer"<<endl;
     
 }
 double dist(double v1,double v2)
 {
     return(sqrt(x-v1)(x-v1)+(y-v2)(y-v2));
 }
 
 ~Point(){
     cout<<"this is diconstructer"
 }
 
};

int main()
{
   int a,b;
   cout<<"Enter The Firts Coordinate:";
   cin>>a;
   cout<<"Enter The Second Coordinate:";
   cin>>b;
   Point p1(a,b);
   
   cout<<"Enter The Firts Coordinate:";
   cin>>a;
   cout<<"Enter The Second Coordinate:";
   cin>>b;
   Point p2(a,b);
   
   cout<<"The distance between Objects are"<<p2.dist(p1.getX(),p1.gety())<<endl;
   

}
