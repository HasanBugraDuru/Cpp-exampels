#include<iostream>
using namespace std;
class Calculate {
	double midterm;
	double final ;
	double homeworks;
	double avg;
	
	public:
		Calculate(double x,double y,double z)
		{
			midterm =x;
			final=y;
			homeworks=z;
	
		}
		double GetAvg()
		{

			avg= midterm * 0.2 + homeworks * 0.2 + final * 0.6 ;
	
		}
		double GetResult()
		{
			return avg;
		}
};
	int main ()
	{
		double a,b,c;
		cout<<"Please Enter Your Midterm Grade =";
 		cin>>a;
 		cout<<"Please Enter Your Final Grade=";
 		cin>>b;
 		cout<<"Please Enter Your Grade From HomeWorks =";
 		cin>>c;
 		
 		Calculate notes(a,b,c);
 		notes.GetAvg();
 		cout<<"Your Semester Average Is ="<< notes.GetResult();
 		
	}

