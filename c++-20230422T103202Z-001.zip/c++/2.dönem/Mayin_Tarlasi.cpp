#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main()
{
	srand(time(NULL));
	int en,boy,bayrak=0,bayrak2=1,tahmn_sys=0,a,b,yakinlik;
	cout<<"Lutfen mayin tarlasinin enini giriniz:";
	cin>>en;
	cout<<"Lutfen mayin tarlasinin boyunu giriniz:";
	cin>>boy;
	int Tarla[boy][en];
	int Tahmin[boy][en];
	for(int i=0;i<boy;i++)
	{
		for(int t=0;t<en;t++)
		{
			Tarla[i][t]= rand() % 2;
		}
		
	}

	for(int i=0;i<boy;i++)
	{
		for(int t=0;t<en;t++)
		{
			Tahmin[i][t]= 1;
		}
		
	}
		/*for(int i=0;i<boy;i++)
	{
		cout<<endl;
		for(int t=0;t<en;t++)
		{
			cout<<Tarla[i][t]<<" ";
		}
		
	} */
	for(int i=0;i<boy;i++)
	{
		cout<<endl;
		for(int t=0;t<en;t++)
		{
			cout<<"# ";
		}
		
	} 

	
		while(bayrak==0)
		{
			tahmn_sys++;
			cout<<endl;
			cout<<"Lutfen "<<tahmn_sys<<". tahmininizin x kordinatini giriniz:";
			cin>>a;
			cout<<"Lutfen "<<tahmn_sys<<". tahmininizin y kordinatini giriniz:";
			cin>>b;
				if(Tarla[b-1][a-1]==1)
				{
					cout<<"BOOOOM!";
					break;
					return 0;
				}
				else
				{
					Tahmin[b-1][a-1]=0;
						for(int i=0;i<boy;i++)
							{
								cout<<endl;
								for(int t=0;t<en;t++)
									{
										if(Tahmin[i][t]==0)
										{
											yakinlik = 0;
											if(Tarla[i-1][t]==1 and i-1>=0 and t>=0)
											{
												yakinlik++;
											}
											if(Tarla[i][t-1]==1 and i>=0 and t-1>=0)
											{
												yakinlik++;
											}
											if(Tarla[i+1][t]==1 and i+1>=0 and t>=0)
											{
												yakinlik++;
											}
											if(Tarla[i][t+1]==1 and i>=0 and t+1>=0)
											{
												yakinlik++;
											}
											
												
									
											cout<<yakinlik<<" ";
										}
										else
										{
											cout<<"# ";
										}
									}
		
							}
						cout<<endl;
					
				}
				
		for(int i=0;i<boy;i++)
		{
			for(int t=0;t<en;t++)
			{
				if(Tarla[i][t]==0 and Tahmin[i][t]==0)
				{
					bayrak2=0;
				}
				else
				{
					bayrak2=1;
				}
			}
		
		}
		if(bayrak2==0)
		{
			cout<<"Tebrikler Butun Bos Alanlari Buldun";
			break;
			return 0;
		}		
				
		}

}
