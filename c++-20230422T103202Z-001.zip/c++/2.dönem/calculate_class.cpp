#include<iostream>
using namespace std;

class Calculate{
	double num1;
	double num2;
	double result;
	int opt;
	
	public:
		Calculate(double x,double y, int z){
			
			num1=x;
			num2=y;
			opt=z;
			
			switch(z)
			{
				case 1:
					result = num1+num2;
					cout<<"Your Answer Is ="<<result;
					break;
			
				case 2:
					result = num1-num2;
					cout<<"Your Answer Is ="<<result;
					break;
			
				case 3:
					result = num1/num2;
					cout<<"Your Answer Is ="<<result;
					break;
				case 4:
					result = num1*num2;
					cout<<"Your Answer Is ="<<result;
					break;
				default:
				cout<<"404 ERROR PLEASE ENTER A RIGTH CHARACTER";	
			}
			
		}
	
};

int main(){
	int a,b,c;
		cout<<"Please Enter First Number= ";
 		cin>>a;
 		cout<<"Please Enter Second Number =";
 		cin>>b;
 		cout<<"Please Enter One Of Those Sembols 1 ='+',2 ='-',3 ='/',4 ='*' =";
 		cin>>c;
 		
 		Calculate notes(a,b,c);
	
	
	
}
