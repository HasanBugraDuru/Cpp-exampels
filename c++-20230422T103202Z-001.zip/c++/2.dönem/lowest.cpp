#include<iostream>
using namespace std;

int main()
{

int num;

cout<<"Enter the number";
cin>>num;

int *nums = new int[num];

	for(int t=0;t<num;t++){
		cout<<"Enter the number "<<t+1;
		cin>>nums[t];	
	}
int lowest=0;
	for(int f=0;f<num;f++){
		if(nums[f]<lowest)
		lowest=nums[f];
	}

cout<<"Lowest Number is "<<lowest;
}
