#include<iostream>
using namespace std;
class Fibonacci{
	int x,y,z,i;
	public:
	Fibonacci(int a){
		x=0;
		y=1;
		i=1;
		while(i<=a){
			cout<<x<<" ";
				z=x+y;
				x=y;
				y=z;
			i++;
		}
	} 
	
	~Fibonacci(){
	}
	
};


int main()
{
	int num;
	
	cout<<"Please Enter legent of Fibonnacci Numbers =";
	cin>>num;
	
	Fibonacci fib(num);
}
