#include<iostream>
using namespace std;
struct student{
	int midterm;
	int final;
	double avg;
};
int main ()
{

	student a;
	cout<<"enter the midterm " ;
	cin>>a.midterm;
	cout<<"enter the final " ;
	cin>>a.final;
	a.avg = (a.midterm*0.4)+(a.final*0.6);
	cout<<"avarage is  " << a.avg ;
}
