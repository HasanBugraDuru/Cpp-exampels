#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	char word[100];
	
	cout<<"please enter your santence";
	gets(word);
	
	cout<<word;
	
	
	
}
