#include<iostream>
using namespace std;
struct fact{
	int num;
	int result;
	
};
int main ()
{

	fact a;
	int i;
	a.result++;
	cout<<"Enter fact= " ;
	cin>>a.num;
	for(i=1;i<=a.num;i++)
		{
			a.result *= i;
		}

	cout<<"Factorial =  " << a.result ;
}
