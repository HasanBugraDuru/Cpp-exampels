#include<iostream>
using namespace std;

int main()
{
	int num1,num2;
	cout<<"Please enter First Number =";
	cin>>num1;
	cout<<"Please enter Second Number =";
	cin>>num2; 
	
	if(num1>num2)
	{
		if(num2%2==0){
			cout<<"Small Number Is dual ";
		}
		else{
			cout<<"Small Number Is Single ";
		}   
	}
	else
	{
		if(num1%2==0){
			cout<<"Small Number Is dual ";
		}
		else{
			cout<<"Small Number Is Single ";
		}   
	}
}
