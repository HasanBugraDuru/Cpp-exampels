#include<iostream>
using namespace std;
int main ()
{
     int a,b;
	s
	cout<<"enter the second number " ;
	cin>>b;
	cout<<"result is ="<<a+b;
	
}
