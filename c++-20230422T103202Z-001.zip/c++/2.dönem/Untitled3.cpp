#include<stdio.h>
int main()
int number,flag=0;
scanf("%d",number)
for(int i=2;i<number;i++)
	{
		if(number%i==0)
			printf("not prime");
		else 		
			flag=1
	}
if(flag==1)
		printf(" prime");	
	
	
