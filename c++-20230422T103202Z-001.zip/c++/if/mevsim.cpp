#include<iostream>
using namespace std;
int main()
{
	int number;
	cout<<"Please Enter a Number Between 1-4";
	cin>>number;
	
	switch(number){
		
		case 1:
			cout<<"ilkbahar";
			break;
		case 2:
			cout<<"yaz";
			break;
		case 3:
			cout<<"sonbahar ";
			break;
		case 4:
			cout<<"k�s";
			break;
		default: cout<<"Hatal� giris";
		
	}
}
