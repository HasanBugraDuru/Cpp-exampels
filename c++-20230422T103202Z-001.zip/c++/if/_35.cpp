#include<iostream>
using namespace std ;
int main()
{
	int number;
	cout<<"please enter the number";
	cin>>number;
	if(number*0.35>1000)
	{
		cout<<"Yes,number is big";
	}
	else 
	{
		cout<<"No,number is not big enough";
	}
	
	
}
