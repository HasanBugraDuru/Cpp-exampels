#include<iostream>
using namespace std;

int main()
{
	int password;
	
	for(int i=0;i<3;i++)
	{
		
		cout<<"Please Enter The Pasword =";
		cin>>password;
		
		if(password==1234)
		{
				cout<<"Welcome To The Board Captain ";
			break;
			return 0;
		}
		else
			cout<<"Wrong Pasword"<<endl;
	}
	
	
	if(password!=1234)	
		cout<<"You are entred Wrong Password 3 Times";
	
	
}
