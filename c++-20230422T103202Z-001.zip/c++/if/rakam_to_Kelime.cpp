#include<iostream>
using namespace std;
char Kelime(int x)
{
	 char rakam;
	switch(x){
		case 1:cout<<"bir";
			break;
		case 2:cout<<"iki";
			break;
		case 3:cout<<"��";
			break;
		case 4:cout<<"d�rt";
			break;
		case 5:cout<<"be�";
			break;	
		case 6:cout<<"alt�";
			break;	
		case 7:cout<<"yedi";
			break;
		case 8:cout<<"sekiz";
			break;
		case 9:cout<<"dokuz";
			break;	
	}
	return rakam;
}
int main()
{
	int sayi,birler;
	cout<<"Lutfen Sayiyi giriniz";
	cin>>sayi;
	birler=sayi%10;
	
	cout<<Kelime(birler);
	
	
}
