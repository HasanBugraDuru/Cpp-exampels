#include<iostream>
using namespace std;
int Ebob(int x,int y)
{
	int Great[8]={2,3,5,7,11,13,17,19};//asal say�lar.
	int ebob=1,i=0;
	while(x!=1 & y!=1)
	{
		if(x%Great[i]==0 && y%Great[i]==0) //iki say�n�n da asal say�ya b�l�n�p b�l�nmedi�i kontrol ediliyor.
		{
			ebob*=Great[i]; //say�lar b�l�nd��� taktirde ebob artyor ve say�lar azal�yor taki say�lar 1 olas�ya kadar.
			x/=Great[i];
			y/=Great[i];
		}
		else
		if(x<Great[i] || y<Great[i])
		{
			break;
		}
		else
		i++;
	}
	return ebob;
}
int main()
{
	int n1,n2;
	cout<<"Please enter first number:";
	cin>>n1;
	cout<<"Please enter second number:";
	cin>>n2;
	
	cout<<"Ebob of two number is "<<Ebob(n1,n2); // fonksiyon �a��r�l�yor.
	
}
