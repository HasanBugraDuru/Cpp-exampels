#include<iostream>
using namespace std;
int Ekok(int x,int y)
{
	int Great[8]={2,3,5,7,11,13,17,19};//asal say�lar.
	int ekok=1,i=0;
	while(x!=1 & y!=1)
	{
		if(x%Great[i]==0 || y%Great[i]==0) //iki say�n�n da asal say�ya b�l�n�p b�l�nmedi�i kontrol ediliyor.
		{
			ekok*=Great[i]; //say�lar b�l�nd��� taktirde ebob artyor ve say�lar azal�yor taki say�lar 1 olas�ya kadar.
			
			if(x%Great[i]==0){
				x/=Great[i];
			}
			if( y%Great[i]==0){
				y/=Great[i];
			}
			
		}
		else
		i++;
	}
	return ekok;
}
int main()
{
	int n1,n2;
	cout<<"Please enter first number:";
	cin>>n1;
	cout<<"Please enter second number:";
	cin>>n2;
	
	cout<<"Ekok of two number is "<<Ekok(n1,n2); // fonksiyon �a��r�l�yor.
	
}
