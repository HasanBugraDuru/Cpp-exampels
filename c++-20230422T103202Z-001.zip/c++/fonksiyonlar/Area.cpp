#include<iostream>
#include<cmath>
using namespace std;
double Area(double x)
{
	double area;
	area=x*x*sqrt(x)/4;
	return area;
}
int main()
{
	double  legth;
	cout<<"Please Enter One Side of triangle :";
	cin>>legth;
	cout<<"Area of Triangle is ="<<Area(legth); 
	
	
}
