#include<iostream>
using namespace std;

int Faktoriyel(int x)
{
	int  fact=1;
	for(int i=1;i<=x;i++)
	{
		fact*=i;
	}
	return fact;
}

float Permutasyon(int a,int b)
{
	float perm;
	
	perm=Faktoriyel(a)/Faktoriyel(a-b);
	return perm;
	
	
}
int main()
{
	int num1,num2;
	cout<<"please enter number one=";
	cin>>num1;
	cout<<"please enter number two=";
	cin>>num2;
	cout<<"Permitasyon ="<<Permutasyon(num1,num2);
	
}
