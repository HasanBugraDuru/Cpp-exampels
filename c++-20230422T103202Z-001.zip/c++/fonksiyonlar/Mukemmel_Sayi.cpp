#include<iostream>
using namespace std;
void Mukemmel()
{
	int sum;
	for(int j=0;j<100;j++)
		{
			sum=0;
			for(int i=1;i<j;i++)
			{
				if(j%i==0)
				sum+=i;
				
			}
			if(sum==j)
			cout<<j<<" is a perfect number"<<endl;
			
}

int main()
{
	Mukemmel();
}
