#include<iostream>
using namespace std;
int summation()
{
	int sum;
	int nums[10];
	for(int i=0;i<10;i++)
	{
		cout<<"Please Enter the "<<i+1<<". number =";
		cin>>nums[i];
		sum+=nums[i];
	}
	return sum; 
}
int main()
{
	int a;
	
	a=summation();
	
	cout<<"Summation is "<<a;
	
	
}
